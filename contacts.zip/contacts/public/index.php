<?php 
require_once("../config/Config.php");
require_once("../libs/Autoload.php");


$obj = new Router();

