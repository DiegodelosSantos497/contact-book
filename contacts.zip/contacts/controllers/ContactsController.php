<?php

class ContactsController extends Controller
{
    public function __construct()
    {
        parent::__construct();
    }

    public function index()
    {
        $data = [
            'title' => 'All contacts',
            'contact' => $this->model->get()
        ];
        require_once("../views/header.php");
        $this->view->render('contacts/index', $data);
        require_once("../views/footer.php");
    }

    public function add()
    {
        $data = ['title' => 'New contact'];
        require_once("../views/header.php");
        $this->view->render('contacts/add', $data);
        require_once("../views/footer.php");
    }

    public function edit()
    {
        $data = [
            'title' => 'Edit contact',
            'contact' => $this->model->getContact($_GET['id'])
        ];
        require_once("../views/header.php");
        $this->view->render('contacts/edit', $data);
        require_once("../views/footer.php");
    }

    public function save()
    {
        $fname = empty($_POST['fname']) ? "" : $_POST['fname'];
        $lname = empty($_POST['lname']) ? "" : $_POST['lname'];
        $address = empty($_POST['address']) ? "" : $_POST['address'];
        $telephone = empty($_POST['telephone']) ? "" : $_POST['telephone'];
        $currentPhoto = empty($_POST['currentPhoto']) ? "" : $_POST['currentPhoto'];
        $photo = empty($_FILES['photo']['name']) ? "" : $_FILES['photo'];
        $id = empty($_POST['id']) ? "" : $_POST['id'];
        $path = "./img/contacts/";
        $extension = pathinfo($photo['name'], PATHINFO_EXTENSION);
        $extension = empty($extension) ? "" : $extension;
        $allowedExtensions = ['jpg', 'jpeg', 'png'];


        if (empty($fname) || empty($lname) || empty($address) || empty($telephone)) {
            redirect("contacts/add");
            message("All fields are required", "error");
        } elseif (empty($id)) {
            if (empty($photo['name'])) {
                redirect("contacts/add");
                message("Photo is required", "error");
            } elseif (!in_array($extension, $allowedExtensions)) {
                redirect("contacts/add");
                message("Photo must be an image", "error");
            } elseif (move_uploaded_file($photo['tmp_name'], $path . $photo['name']) && $this->model->insert($fname, $lname, $address, $telephone, $photo['name'])) {
                redirect("contacts/add");
                message("Contact inserted successfully", "success");
            } else {
                redirect("contacts/add");
                message("Error insertig the contact", "error");
            }
        } else {
            if (empty($photo['name'])) {
                if ($this->model->update($id, $fname, $lname, $address, $telephone, $currentPhoto)) {
                    redirect("contacts/index");
                    message("Contact updated successfully", "success");
                } else {
                    redirect("contacts/edit?id=$id");
                    message("Error updating the contact", "error");
                }
            } else {
                if (!in_array($extension, $allowedExtensions)) {
                    redirect("contacts/edit?id=$id");
                    message("Photo must be an image", "error");
                } else {
                    if (
                        $this->model->update($id, $fname, $lname, $address, $telephone, $photo['name']) &&
                        unlink($path . $currentPhoto) &&
                        move_uploaded_file($photo['tmp_name'], $path . $photo['name'])
                    ) {
                        redirect("contacts/index");
                        message("Contact updated successfully", "success");
                    } else {
                        redirect("contacts/edit?id=$id");
                        message("Error updating the contact", "error");
                    }
                }
            }
        }
    }

    public function delete()
    {
        $path = "./img/contacts/";
        if (empty($_GET['id']) || empty($_GET['photo'])) {
            echo "Error comuniquese con el programador";
        } else {
            if (unlink($path . $_GET['photo']) && $this->model->delete($_GET['id'])) {
                redirect("contacts/index");
                message("Contacto eliminado con éxito", "success");
            } else {
                redirect("contacts/index");
                message("No se pudo eliminar el contacto", "error");
            }
        }
    }
}
