<?php

class HomeController extends Controller
{
    public function __construct()
    {
        parent::__construct();
    }

    public function index()
    {
        $data = ['title' => 'Home'];
        require_once("../views/header.php");
        $this->view->render('home/index', $data);
        require_once("../views/footer.php");
    }
}
