<?php

class ContactsModel extends Model
{

    public function __construct()
    {
        parent::__construct();
    }

    public function insert($fname, $lname, $address, $telephone, $photo)
    {
        try {
            $stmt = $this->db->connect()->prepare('INSERT INTO contact(contact_fname, contact_lname, contact_address, contact_telephone, contact_photo ) VALUES(:contact_fname, :contact_lname, :contact_address, :contact_telephone, :contact_photo)');
            $stmt->bindParam(":contact_fname", $fname, PDO::PARAM_STR);
            $stmt->bindParam(":contact_lname", $lname, PDO::PARAM_STR);
            $stmt->bindParam(":contact_address", $address, PDO::PARAM_STR);
            $stmt->bindParam(":contact_telephone", $telephone, PDO::PARAM_STR);
            $stmt->bindParam(":contact_photo", $photo, PDO::PARAM_STR);
            if ($stmt->execute()) {
                return true;
            } else {
                return false;
            }
        } catch (PDOException $e) {
            print("Error: " . $e->getMessage());
            die();
        }
    }

    public function get()
    {
        try {
            $stmt = $this->db->connect()->query("SELECT * FROM contact");
            $stmt->execute();
            return $stmt->fetchAll(PDO::FETCH_OBJ);
        } catch (PDOException $e) {
            print("Error: " . $e->getMessage());
            die();
        }
    }

    public function delete($id)
    {
        try {
            $stmt = $this->db->connect()->prepare('DELETE FROM contact WHERE contact_id = :contact_id');
            $stmt->bindParam(":contact_id", $id, PDO::PARAM_INT);
            $stmt->execute();
            return true;
        } catch (PDOException $e) {
            print("Error: " . $e->getMessage());
            die();
        }
    }

    public function getContact($id)
    {
        try {
            $stmt = $this->db->connect()->prepare('SELECT * FROM contact WHERE contact_id = :contact_id');
            $stmt->bindParam(":contact_id", $id, PDO::PARAM_INT);
            if ($stmt->execute()) {
                return $stmt->fetch(PDO::FETCH_OBJ);
            } else {
                return false;
            }
        } catch (PDOException $e) {
            print("Error: " . $e->getMessage());
            die();
        }
    }

    public function update($id, $fname, $lname, $address, $telephone, $photo)
    {
        try {
            $stmt = $this->db->connect()->prepare('UPDATE contact SET contact_fname = :contact_fname, contact_lname = :contact_lname, contact_address = :contact_address, contact_telephone = :contact_telephone, contact_photo = :contact_photo WHERE contact_id = :contact_id');
            $stmt->bindParam(":contact_id", $id, PDO::PARAM_INT);
            $stmt->bindParam(":contact_fname", $fname, PDO::PARAM_STR);
            $stmt->bindParam(":contact_lname", $lname, PDO::PARAM_STR);
            $stmt->bindParam(":contact_address", $address, PDO::PARAM_STR);
            $stmt->bindParam(":contact_telephone", $telephone, PDO::PARAM_STR);
            $stmt->bindParam(":contact_photo", $photo, PDO::PARAM_STR);
            if ($stmt->execute()) {
                return true;
            } else {
                return false;
            }
        } catch (PDOException $e) {
            print("Error: " . $e->getMessage());
            die();
        }
    }
}
