<?php
require_once("../controllers/ErrorController.php");
class Router
{
    public function __construct()
    {
        /* recuperamos los parametros de la variable url definida  en el htaccess y almacenamos en la variable $url */
        $url = isset($_GET['url']) ? $_GET['url'] : null;
        /* rtrim() - Retira los espacios en blanco (u otros caracteres) del final de un string */
        $url = rtrim($url, '/');
        /* explode() - Divide un string en varios string */
        $url = explode('/', $url);

        /* 
            empty() — Determina si una variable está vacía.
            verificamos si la variable $url en la posicion 0 está vacía
        */
        if (empty($url[0])) {
            /* guardamos la ruta del controllador home(controlador por defecto) en la variable $fileController */
            $fileController = '../controllers/HomeController.php';
            /* 
            require_once() - La sentencia require_once es idéntica a require excepto que PHP 
            verificará si el archivo ya ha sido incluido y si es así, no se incluye (require) de nuevo.
            Requerimos el archivo $fileController 
            */
            require_once($fileController);
            /* hacemos la inscancia del controlador */
            $controller = new HomeController();
            /* llamamos el método loadModel(para cargar el modelo) */
            $controller->loadModel($url[0]);
            /* llamamos el método index(método por defecto) del controlador HomeController */
            $controller->index();
            return false;
        } else {
            $fileController = '../controllers/' . ucfirst($url[0]) . 'Controller.php';
            /* file_exists() — Comprueba si existe un fichero o directorio */
            if (file_exists($fileController)) {
                require_once($fileController);
                $controllerName = ucfirst($url[0]) . 'Controller';
                $controller = new $controllerName;
                $controller->loadModel($url[0]);
                /* isset() — Determina si una variable está definida y no es null */
                if (isset($url[1])) {
                    /* method_exists() — Comprueba si existe un método de una clase */
                    if (method_exists($controller, $url[1])) {
                        $controller->{$url[1]}();
                    } else {
                        $controller->index();
                    }
                } else {
                    $controller->index();
                }
            } else {
                /* si el controlador ingresado no existe, llamamos al controlador ErrorController()
                 y mostramos la vista de error 404 */
                $controller = new ErrorController();
            }
        }
    }
}
