<?php

class Model
{

    public function __construct()
    {
        $this->db = new Connection();
    }

    /* public function prepare()
    {
        $this->db->connect->prepare();
    }

    public function query($sql)
    {
        $this->db->connect->query($sql);
    } */
}
