<?php

class Controller
{
    public function __construct()
    {$this->view = new View(); }

    public function loadModel($model)
    {
        $url = '../models/' . ucfirst($model) . 'Model.php';
        if (file_exists($url)) {
            $modelName = ucfirst($model) . 'Model';
            require_once("../models/".$modelName.'.php');
            $this->model = new $modelName();
        }
    }
}