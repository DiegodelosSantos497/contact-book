<?php

class View
{
    public function __construct(){
    }

    public function render($name, $data = [])
    {
        require_once("../views/" . $name . ".php");
    }
}
