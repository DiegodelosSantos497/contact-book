<?php

function autoload($class)
{
    $file = "../libs/" . ucwords($class) . ".php";
    if (file_exists($file)) {
        require_once($file);
    }
}

/* spl_autoload_register() — Registra una función con la cola de __autoload proporcionada por spl. 
Si la cola aún no está activa, será activada. 
*/
spl_autoload_register('autoload');
