<?php

session_start();

/* ------------------------------------------- */
define("URL", "http://localhost/contacts");
define("WEBNAME", "Contacts");


/* -------------------------------------------- */
define("HOST", "localhost");
define("DB", "contacts");
define("USER", "root");
define("PASS", "");
define("CHARSET", "utf8");

/* ----------------------------- */

function redirect($path)
{
    header("location:".URL."/{$path}");
}

function message($text, $type)
{
    $_SESSION['message']['text'] = $text;
    $_SESSION['message']['type'] = $type;
    return $_SESSION['message'];
}
