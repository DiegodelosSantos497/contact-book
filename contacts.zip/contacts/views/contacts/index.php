  <!-- Begin Page Content -->
  <div class="container-fluid">

      <!-- Page Heading -->
      <div class="d-sm-flex align-items-center justify-content-between mb-4">
          <h1 class="h3 mb-0 text-gray-800"><?= $data['title'] ?></h1>
          <a href="<?= URL; ?>/contacts/add" class="d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm"><i class="fas fa-plus fa-sm text-white-50"></i> Add contact</a>
      </div>

      <!-- Content Row -->
      <div class="row">
          <div class="col-md-12">
              <div class="card text-center">
                  <div class="card-body">
                      <table class="table text-center">
                          <thead class="thead-dark">
                              <tr>
                                  <th>#</th>
                                  <th>First Name</th>
                                  <th>Last Name</th>
                                  <th>Address</th>
                                  <th>Telephone</th>
                                  <th>Photo</th>
                                  <th>Actions</th>
                              </tr>
                          </thead>
                          <tbody>
                              <? foreach ($data['contact'] as $value) { ?>
                                  <tr>
                                      <th><?= $value->contact_id; ?></th>
                                      <td><?= $value->contact_fname; ?></td>
                                      <td><?= $value->contact_lname; ?></td>
                                      <td><?= $value->contact_address; ?></td>
                                      <td><?= $value->contact_telephone; ?></td>
                                      <td><img style="height: 70px;" class="rounded-circle" src="<?= URL . "/public/img/contacts/" . $value->contact_photo; ?>" alt="Contact photo"></td>
                                      <td>
                                          <a href="<?= URL . "/contacts/edit?id=" . $value->contact_id; ?>" class="btn btn-warning btn-sm">Update</a>
                                          <a href="<?= URL . "/contacts/delete?id=" . $value->contact_id."&photo=".$value->contact_photo; ?>" class="btn btn-danger btn-sm">Delete</a>
                                      </td>
                                  </tr>
                              <? } ?>
                          </tbody>
                      </table>
                  </div>
              </div>
          </div>

      </div>

  </div>
  <!-- /.container-fluid -->