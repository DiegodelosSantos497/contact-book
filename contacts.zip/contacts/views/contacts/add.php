  <!-- Begin Page Content -->
  <div class="container-fluid">

      <!-- Page Heading -->
      <div class="d-sm-flex align-items-center justify-content-between mb-4">
          <h1 class="h3 mb-0 text-gray-800"><?= $data['title'] ?></h1>
          <a href="<?= URL; ?>/contacts/" class="d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm"><i class="fas fa-list fa-sm text-white-50"></i> All contacts</a>
      </div>

      <!-- Content Row -->
      <div class="row">
          <div class="col-md-12">
              <div class="card">
                  <div class="card-body">
                      <form action="<?= URL; ?>/contacts/save" method="post" enctype="multipart/form-data">
                          <div class="form-row">
                              <div class="col-6">
                                  <div class="form-group">
                                      <label for="">First Name</label>
                                      <input type="text" name="fname" class="form-control">
                                  </div>
                              </div>
                              <div class="col-6">
                                  <div class="form-group">
                                      <label for="">Last Name</label>
                                      <input type="text" name="lname" class="form-control">
                                  </div>
                              </div>
                          </div>
                          <div class="form-row">
                              <div class="col-6">
                                  <div class="form-group">
                                      <label for="">Address</label>
                                      <input type="text" name="address" class="form-control">
                                  </div>
                              </div>
                              <div class="col-6">
                                  <div class="form-group">
                                      <label for="">Telephone</label>
                                      <input type="text" name="telephone" class="form-control">
                                  </div>
                              </div>
                          </div>
                          <div class="form-row">
                              <div class="col-6">
                                  <div class="form-group">
                                      <label for="">Photo</label>
                                      <input type="file" name="photo" class="custom-control">
                                  </div>
                              </div>
                          </div>
                          <div class="form-row mt-2">
                              <div class="col-12">
                                  <button type="submit" class="btn btn-primary btn-block">Save</button>
                              </div>
                          </div>
                      </form>
                  </div>
              </div>
          </div>

      </div>

  </div>
  <!-- /.container-fluid -->