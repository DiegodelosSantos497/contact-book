  <!-- Begin Page Content -->
  <div class="container-fluid">
      <!-- Content Row -->
      <div class="row">
          <div class="col-md-12">
              <div class="card text-center">
                  <div class="card-body">
                      <h1 class="text-danger">Error <i class="far fa-frown"></i></h1>
                      <p class="card-text">Page not found.</p>
                      <a href="<?=URL;?>/home/index" class="btn btn-primary">Go home</a>
                  </div>
              </div>
          </div>
      </div>
  </div>
  <!-- /.container-fluid -->