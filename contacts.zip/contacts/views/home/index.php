  <!-- Begin Page Content -->
  <div class="container-fluid">

      <!-- Page Heading -->
      <div class="d-sm-flex align-items-center justify-content-between mb-4">
          <h1 class="h3 mb-0 text-gray-800"><?= $data['title'] ?></h1>
      </div>

      <!-- Content Row -->
      <div class="row">
          <div class="col-12">
              <h2>This is a simple contact book made with PHP and Mysql</h2>
          </div>
      </div>

  </div>
  <!-- /.container-fluid -->